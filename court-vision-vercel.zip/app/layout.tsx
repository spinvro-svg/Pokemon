import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "COURT VISION — Basketball Lab",
  description: "Build a squad, read the floor, and take over the hardwood.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
