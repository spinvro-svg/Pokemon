 "use client";

import { useMemo, useState } from "react";

type Player = { id: number; name: string; pos: string; ovr: number; shooting: number; defense: number; playmaking: number; color: string };
const pool: Player[] = [
 {id:1,name:"Jalen Cross",pos:"PG",ovr:91,shooting:88,defense:77,playmaking:96,color:"#65d6ff"},
 {id:2,name:"Milo Hayes",pos:"SG",ovr:87,shooting:94,defense:72,playmaking:79,color:"#ff8a5b"},
 {id:3,name:"Andre King",pos:"SF",ovr:89,shooting:83,defense:88,playmaking:84,color:"#b4f06b"},
 {id:4,name:"Darius Stone",pos:"PF",ovr:86,shooting:75,defense:92,playmaking:70,color:"#d6a4ff"},
 {id:5,name:"Zion Brooks",pos:"C",ovr:90,shooting:66,defense:95,playmaking:73,color:"#ffce64"},
 {id:6,name:"Cam Rivers",pos:"PG",ovr:82,shooting:80,defense:71,playmaking:86,color:"#6ee7b7"},
 {id:7,name:"Trey Maddox",pos:"SG",ovr:85,shooting:90,defense:78,playmaking:76,color:"#fca5a5"},
 {id:8,name:"Kai Bennett",pos:"SF",ovr:84,shooting:82,defense:85,playmaking:79,color:"#93c5fd"},
 {id:9,name:"Malik Ward",pos:"PF",ovr:81,shooting:72,defense:88,playmaking:75,color:"#f0abfc"},
 {id:10,name:"Noah Banks",pos:"C",ovr:83,shooting:61,defense:89,playmaking:68,color:"#fdba74"},
 {id:11,name:"Eli Parker",pos:"SG",ovr:80,shooting:86,defense:69,playmaking:73,color:"#a7f3d0"},
 {id:12,name:"Rico James",pos:"SF",ovr:79,shooting:78,defense:81,playmaking:74,color:"#c4b5fd"},
];
const starters = ["PG","SG","SF","PF","C"];
const plays = [
 {name:"PICK & ROLL",detail:"Create a lane for your ball handler.",icon:"↗",type:"rim"},
 {name:"SPOT-UP THREE",detail:"Kick it out and let it fly.",icon:"◎",type:"three"},
 {name:"POST-UP",detail:"Go to work close to the basket.",icon:"▣",type:"post"},
 {name:"FAST BREAK",detail:"Push the pace before they set.",icon:"⚡",type:"break"},
];
export default function Home() {
 const [lineup,setLineup] = useState<Record<string,Player>>({});
 const [tab,setTab] = useState("ROSTER");
 const [selected,setSelected] = useState("PG");
 const [mode,setMode] = useState<"build"|"game">("build");
 const [home,setHome] = useState(0);
 const [away,setAway] = useState(0);
 const [quarter,setQuarter] = useState(1);
 const [clock,setClock] = useState("12:00");
 const [log,setLog] = useState<string[]>(["Tip-off is coming. Build your starting five to get on the floor."]);
 const [lastPlay,setLastPlay] = useState("READY FOR TIP-OFF");
 const [possessions,setPossessions] = useState(0);
 const available = useMemo(()=>pool.filter(p=>!Object.values(lineup).some(x=>x.id===p.id)),[lineup]);
 const full = starters.every(s=>lineup[s]);
 const avg = full ? Math.round(starters.reduce((n,s)=>n+lineup[s].ovr,0)/5) : 0;
 function addPlayer(p:Player) {
   setLineup(old=>({...old,[selected]:p}));
 }
 function startGame() {
   if(!full) return;
   setMode("game"); setTab("PLAYBOOK"); setHome(0);setAway(0);setQuarter(1);setClock("12:00");setPossessions(0);
   setLog(["Tip-off! Your squad is on the floor. Call your first play."]);setLastPlay("TIP-OFF");
 }
 function callPlay(play:typeof plays[number]) {
   if(quarter>4 || (quarter===4 && clock==="00:00")) return;
   const team=Object.values(lineup);
   const shoot=team.reduce((n,p)=>n+p.shooting,0)/5;
   const defense=team.reduce((n,p)=>n+p.defense,0)/5;
   const makeChance=Math.min(.82,Math.max(.2, .34+(shoot-75)*.009 + (play.type==="three"?.02:play.type==="rim"?.08:play.type==="post"?.04:.06)));
   const made=Math.random()<makeChance;
   const pts=play.type==="three"?3:2;
   const scored=made?pts:0;
   const oppChance=Math.min(.75,Math.max(.2,.42-(defense-75)*.006));
   const oppMade=Math.random()<oppChance;
   const oppPts=oppMade?(Math.random()<.32?3:2):0;
   setHome(v=>v+scored);setAway(v=>v+oppPts);setPossessions(v=>v+1);
   const seconds= Math.max(0,Number(clock.split(":")[0])*60+Number(clock.split(":")[1])-Math.floor(17+Math.random()*8));
   const nextClock=`${String(Math.floor(seconds/60)).padStart(2,"0")}:${String(seconds%60).padStart(2,"0")}`;
   let nextQ=quarter;
   if(seconds===0){nextQ=Math.min(4,quarter+1);setQuarter(nextQ);}
   setClock(nextClock);
   const headline=made?`${play.name}: BUCKET! +${pts}`:`${play.name}: MISSED SHOT`;
   const opp=oppPts?` Opponent answers with ${oppPts}.`:" Your defense gets the stop.";
   setLastPlay(headline);
   setLog(old=>[`${headline}.${opp}`, ...old].slice(0,5));
 }
 function reset(){setLineup({});setMode("build");setTab("ROSTER");setHome(0);setAway(0);setQuarter(1);setClock("12:00");setPossessions(0);setLog(["Tip-off is coming. Build your starting five to get on the floor."]);setLastPlay("READY FOR TIP-OFF")}
 return <main className="shell">
   <header className="topbar">
    <div className="brand"><div className="brandball">◉</div><div><strong>COURT<span>VISION</span></strong><small>BASKETBALL LAB</small></div></div>
    <nav>{["ROSTER","PLAYBOOK","SCOUTING"].map(t=><button key={t} className={tab===t?"nav active":"nav"} onClick={()=>setTab(t)}>{t}</button>)}</nav>
    <div className="status"><span className="live-dot"></span> OFFLINE LEAGUE</div>
   </header>
   <section className="hero">
    <div><div className="eyebrow">YOUR TEAM. YOUR CALL.</div><h1>Own the <em>hardwood.</em></h1><p>Draft your five. Read the defense. Make every possession count.</p></div>
    <div className="hero-stats"><div><small>TEAM OVR</small><b>{avg||"—"}</b></div><div><small>STARTERS</small><b>{Object.keys(lineup).length}<i>/5</i></b></div><div><small>RECORD</small><b>0<i>–0</i></b></div></div>
   </section>
   <div className="modebar">
    <button className={mode==="build"?"mode selected":"mode"} onClick={()=>{setMode("build");setTab("ROSTER")}}><span>01</span><b>BUILD YOUR SQUAD</b><small>Pick a starting five</small></button>
    <button className={mode==="game"?"mode selected":"mode"} onClick={()=>{if(full){setMode("game");setTab("PLAYBOOK")}}}><span>02</span><b>CALL THE GAME</b><small>Choose your next play</small></button>
    <div className="mode-note"><span className="pulse"></span> {mode==="build"?"ROSTER ROOM":"GAME DAY"} <small>· LOCAL SAVE</small></div>
   </div>
   <div className="layout">
    <section className="mainpanel">
     {mode==="build" ? <>
      <div className="panelhead"><div><div className="eyebrow">FRONT OFFICE / 01</div><h2>Build your starting five</h2><p>Choose a position, then draft a player from the board.</p></div><span className="pill">{Object.keys(lineup).length===5?"ROSTER READY":`${Object.keys(lineup).length}/5 SELECTED`}</span></div>
      <div className="court">
       <div className="court-lines"><div className="center-circle"></div><div className="center-line"></div><div className="key left-key"></div><div className="key right-key"></div><div className="arc left-arc"></div><div className="arc right-arc"></div><div className="hoop left-hoop"></div><div className="hoop right-hoop"></div></div>
       <div className="court-label">COURT VISION ARENA <span>HOME FLOOR</span></div>
       {starters.map((pos,i)=>{const coords=[{x:17,y:50},{x:31,y:27},{x:50,y:50},{x:68,y:27},{x:83,y:50}][i];const p=lineup[pos];return <button key={pos} className={`court-player ${selected===pos?"chosen":""} ${p?"filled":""}`} style={{left:`${coords.x}%`,top:`${coords.y}%`,["--player-color" as string]:p?.color||"#8193a8"}} onClick={()=>setSelected(pos)}><span className="player-ring">{p? p.name.split(" ").map(n=>n[0]).join(""):"+"}</span><b>{pos}</b><small>{p?p.name:"OPEN SLOT"}</small></button>})}
      </div>
      <div className="positions"><div className="sectionline"><b>STARTING LINEUP</b><span>SELECT A POSITION TO FILL</span></div><div className="positiongrid">{starters.map(pos=><button key={pos} className={`poscard ${selected===pos?"posactive":""}`} onClick={()=>setSelected(pos)}><span>{pos}</span><b>{lineup[pos]?.name||"Open spot"}</b><small>{lineup[pos]?`OVR ${lineup[pos].ovr}`:"Tap to draft"}</small><i>{lineup[pos]?"✓":"＋"}</i></button>)}</div></div>
      <div className="sectionline roster-title"><b>AVAILABLE PLAYERS</b><span>{available.length} FREE AGENTS</span></div>
      <div className="players">{available.map(p=><button key={p.id} className="playercard" onClick={()=>addPlayer(p)}><div className="avatar" style={{background:p.color}}>{p.name.split(" ").map(n=>n[0]).join("")}</div><div className="playerinfo"><b>{p.name}</b><small>{p.pos} · SHO {p.shooting} / DEF {p.defense}</small></div><strong>{p.ovr}</strong><span className="draftplus">+</span></button>)}</div>
      <div className="bottom-actions"><button className="ghost" onClick={reset}>RESET ROSTER</button><button className="primary" disabled={!full} onClick={startGame}>{full?"TAKE THE COURT  →":"FILL ALL FIVE POSITIONS  →"}</button></div>
     </> : <>
      <div className="panelhead"><div><div className="eyebrow">LIVE GAME / POSSESSION MODE</div><h2>Make the next move.</h2><p>Pick a play and let your lineup execute.</p></div><span className="pill live-pill"><span className="live-dot"></span> LIVE SIM</span></div>
      <div className="scoreboard"><div className="teamblock"><div className="teamlogo">CV</div><div><small>HOME</small><b>COURT VISION</b></div></div><div className="score"><strong>{home}</strong><span>—</span><strong>{away}</strong></div><div className="gameclock"><small>Q{quarter}</small><b>{clock}</b><small>{possessions} POS</small></div></div>
      <div className="gamecourt">
       <div className="court-lines"><div className="center-circle"></div><div className="center-line"></div><div className="key left-key"></div><div className="key right-key"></div><div className="arc left-arc"></div><div className="arc right-arc"></div><div className="hoop left-hoop"></div><div className="hoop right-hoop"></div></div>
       {starters.map((pos,i)=>{const p=lineup[pos];const coords=[{x:20,y:54},{x:36,y:28},{x:49,y:50},{x:66,y:31},{x:78,y:57}][i];return <div key={pos} className="gameplayer" style={{left:`${coords.x}%`,top:`${coords.y}%`}}><span style={{background:p?.color}}>{p?.name.split(" ").map(n=>n[0]).join("")}</span><small>{pos}</small></div>})}
       <div className="ball-marker">●</div><div className="play-label">{lastPlay}</div>
      </div>
      <div className="playgrid">{plays.map(p=><button key={p.name} className="playcard" onClick={()=>callPlay(p)}><span>{p.icon}</span><b>{p.name}</b><small>{p.detail}</small><i>CALL PLAY ↗</i></button>)}</div>
      <div className="sectionline logline"><b>PLAY-BY-PLAY</b><span>RECENT POSSESSIONS</span></div><div className="log">{log.map((l,i)=><div key={i}><span>{String(log.length-i).padStart(2,"0")}</span>{l}</div>)}</div>
      <div className="bottom-actions"><button className="ghost" onClick={()=>{setMode("build");setTab("ROSTER")}}>← EDIT LINEUP</button><button className="primary" onClick={()=>{setMode("build");setTab("ROSTER");setLineup({})}}>NEW GAME +</button></div>
     </>}
    </section>
    <aside className="sidebar">
     <div className="sidecard"><div className="sidehead"><span className="sideicon">⌁</span><div><b>{mode==="build"?"SCOUTING REPORT":"COACH'S BOARD"}</b><small>{mode==="build"?"BUILD A BALANCED TEAM":"READ THE MOMENT"}</small></div></div>
      {mode==="build"?<><p className="sidecopy">A great lineup has a little bit of everything. Check the numbers before you draft.</p><div className="metric"><span>SHOOTING</span><div><i style={{width:`${full?Math.round(starters.reduce((n,s)=>n+lineup[s].shooting,0)/5):82}%`}}></i></div><b>{full?Math.round(starters.reduce((n,s)=>n+lineup[s].shooting,0)/5):"—"}</b></div><div className="metric"><span>DEFENSE</span><div><i style={{width:`${full?Math.round(starters.reduce((n,s)=>n+lineup[s].defense,0)/5):82}%`}}></i></div><b>{full?Math.round(starters.reduce((n,s)=>n+lineup[s].defense,0)/5):"—"}</b></div><div className="metric"><span>PLAYMAKING</span><div><i style={{width:`${full?Math.round(starters.reduce((n,s)=>n+lineup[s].playmaking,0)/5):82}%`}}></i></div><b>{full?Math.round(starters.reduce((n,s)=>n+lineup[s].playmaking,0)/5):"—"}</b></div><div className="tip"><b>✦ PRO TIP</b><p>Pick a point guard who can create, shooters who space the floor, and a center who protects the rim.</p></div></>:<><p className="sidecopy">The play call changes your odds. Match the action to your roster's strengths.</p>{plays.map(p=><div className="playhint" key={p.name}><b>{p.name}</b><small>{p.type==="three"?"Best with high shooting ratings.":p.type==="rim"?"Uses playmaking to create a lane.":p.type==="post"?"Works best with a strong frontcourt.":"Attack before the defense gets set."}</small></div>)}</>}
     </div>
     <div className="sidecard progress"><div className="sidehead"><span className="sideicon gold">✦</span><div><b>SEASON TRACKER</b><small>YOUR CAREER STARTS HERE</small></div></div><div className="progressbig"><b>{mode==="game"?home:"0"}</b><span>POINTS SCORED</span></div><div className="progressrow"><span>Games played</span><b>{mode==="game"?1:0}</b></div><div className="progressrow"><span>Best team OVR</span><b>{avg||"—"}</b></div><div className="progressrow"><span>Win streak</span><b>0</b></div><div className="progressbar"><i style={{width:`${Object.keys(lineup).length*20}%`}}></i></div><small className="progressfoot">{Object.keys(lineup).length}/5 roster slots filled</small></div>
     <div className="sidecard objective"><div className="eyebrow">TODAY'S OBJECTIVE</div><h3>{mode==="build"?"Assemble the five.":"Own the fourth."}</h3><p>{mode==="build"?"Draft five players and balance offense with defense to unlock game day.":"Keep calling smart plays and finish with more points than the opponent."}</p><div className="objective-bottom"><span>REWARD</span><b>+250 XP</b></div></div>
     <div className="footer-note">COURT VISION <span>•</span> A BASKETBALL MINI-GAME<br/><small>Original fan-made concept. No official league affiliation.</small></div>
    </aside>
   </div>
 </main>
}
